﻿(function () {
    var control = angular.module('app.controllers');

    control.controller('Res15CrecienteCtrl', function ($scope, $state, Simula, Avaluos, Calculos, GastosNotariales) {
        $scope.valor = $state.params.valor;
        $scope.selEstado = $state.params.selEstado;
        $scope.selMens = $state.params.selMens;
        $scope.selPlazo = $state.params.selPlazo;
        gastosNotarialesXEstado = GastosNotariales.get($scope.selEstado).gastoNotarial;

        $scope.toggleGroup = function (group) {
            if ($scope.isGroupShown(group)) {
                $scope.shownGroup = null;
            } else {
                $scope.shownGroup = group;
            }
        };
        $scope.isGroupShown = function (group) {
            return $scope.shownGroup === group;
        };

        //Banorte
        banorte = Simula.getForCalc(1, $scope.selMens, $scope.selPlazo);
        var grpBanorte = [];
        grpBanorte.push({
            name: banorte.nombreBanco,
            members: []
        });

        aforo = banorte.aforo;
        factorPago = banorte.factorDePago;
        tasaInteres = banorte.tasaDeInteres;
        cat = banorte.cat;

        montoCredito = Calculos.calculaMotoDelCredito(banorte.aforo, $scope.valor);
        pagoMensual = Calculos.calcularPagoMensual(montoCredito, factorPago);
        ingresoRequerido = Calculos.calculoIngresoRequeridoCreciente(pagoMensual, 1);

        enganche = Calculos.calculoEnganche($scope.valor, montoCredito);
        avaluo = Calculos.calcularAvaluoCreciente($scope.valor, 1, Avaluos);
        comisionApertura = Calculos.calculoComisionApertura(montoCredito, 1);
        gastosNotariales = Calculos.calculoGastosNotariales($scope.valor, gastosNotarialesXEstado);

        desembolsoTotal = parseFloat(enganche) + parseFloat(avaluo) + parseFloat(comisionApertura) + parseFloat(gastosNotariales);

        grpBanorte[0].members.push({ name: "Pago mensual", quantity: '$' + pagoMensual.formatMoney(2, '.', ',') });
        grpBanorte[0].members.push({ name: "Monto del credito", quantity: '$' + montoCredito.formatMoney(2, '.', ',') });
        grpBanorte[0].members.push({ name: "Tasa de interes", quantity: (tasaInteres * 100).toFixed(2) + '%' });
        grpBanorte[0].members.push({ name: "Ingreso requerido", quantity: '$' + ingresoRequerido.formatMoney(2, '.', ',') });
        grpBanorte[0].members.push({ name: "Incremento anual del pago", quantity: parseFloat(banorte.incrementoAnual * 100).toFixed(2) + "%" });
        grpBanorte[0].members.push({ name: "CAT", quantity: (cat * 100).toFixed(2) + '%' });
        grpBanorte[0].members.push({ name: "Gastos del credito", quantity: undefined });
        grpBanorte[0].members.push({ name: "Enganche", quantity: '$' + enganche.formatMoney(2, '.', ',') });
        grpBanorte[0].members.push({ name: "Avaluo", quantity: '$' + avaluo.formatMoney(2, '.', ',') });
        grpBanorte[0].members.push({ name: "Comision por apertura", quantity: '$' + comisionApertura.formatMoney(2, '.', ',') });
        grpBanorte[0].members.push({ name: "Gastos notariales", quantity: '$' + gastosNotariales.formatMoney(2, '.', ',') });
        grpBanorte[0].members.push({ name: "Desembolso total", quantity: '$' + desembolsoTotal.formatMoney(2, '.', ',') });
        $scope.grupoBanorte = grpBanorte;

        aforo = 0;
        factorPago = 0;
        tasaInteres = 0;
        cat = 0;
        montoCredito = 0;
        pagoMensual = 0;
        ingresoRequerido = 0;
        enganche = 0;
        avaluo = 0;
        comisionApertura = 0;
        gastosNotariales = 0;
        desembolsoTotal = 0;

        // Santander
        santander = Simula.getForCalc(2, $scope.selMens, $scope.selPlazo);
        var grpSantander = [];
        grpSantander.push({
            name: santander.nombreBanco,
            members: []
        });

        aforo = santander.aforo;
        factorPago = santander.factorDePago;
        tasaInteres = santander.tasaDeInteres;
        cat = santander.cat;

        montoCredito = Calculos.calculaMotoDelCredito(santander.aforo, $scope.valor);
        pagoMensual = Calculos.calcularPagoMensual(montoCredito, factorPago);
        ingresoRequerido = Calculos.calculoIngresoRequeridoCreciente(pagoMensual, 2);

        enganche = Calculos.calculoEnganche($scope.valor, montoCredito);
        avaluo = Calculos.calcularAvaluoCreciente($scope.valor, 2, Avaluos);
        comisionApertura = Calculos.calculoComisionApertura(montoCredito, 2);
        gastosNotariales = Calculos.calculoGastosNotariales($scope.valor, gastosNotarialesXEstado);

        desembolsoTotal = parseFloat(enganche) + parseFloat(avaluo) + parseFloat(comisionApertura) + parseFloat(gastosNotariales);

        grpSantander[0].members.push({ name: "Pago mensual", quantity: '$' + pagoMensual.formatMoney(2, '.', ',') });
        grpSantander[0].members.push({ name: "Monto del credito", quantity: '$' + montoCredito.formatMoney(2, '.', ',') });
        grpSantander[0].members.push({ name: "Tasa de interes", quantity: (tasaInteres * 100).toFixed(2) + '%' });
        grpSantander[0].members.push({ name: "Ingreso requerido", quantity: '$' + ingresoRequerido.formatMoney(2, '.', ',') });
        grpSantander[0].members.push({ name: "Incremento anual del pago", quantity: parseFloat(banorte.incrementoAnual * 100).toFixed(2) + "%" });
        grpSantander[0].members.push({ name: "CAT", quantity: (cat * 100).toFixed(2) + '%' });
        grpSantander[0].members.push({ name: "Gastos del credito", quantity: undefined });
        grpSantander[0].members.push({ name: "Enganche", quantity: '$' + enganche.formatMoney(2, '.', ',') });
        grpSantander[0].members.push({ name: "Avaluo", quantity: '$' + avaluo.formatMoney(2, '.', ',') });
        grpSantander[0].members.push({ name: "Comision por apertura", quantity: '$' + comisionApertura.formatMoney(2, '.', ',') });
        grpSantander[0].members.push({ name: "Gastos notariales", quantity: '$' + gastosNotariales.formatMoney(2, '.', ',') });
        grpSantander[0].members.push({ name: "Desembolso total", quantity: '$' + desembolsoTotal.formatMoney(2, '.', ',') });

        $scope.grupoSantander = grpSantander;

        aforo = 0;
        factorPago = 0;
        tasaInteres = 0;
        cat = 0;
        montoCredito = 0;
        pagoMensual = 0;
        ingresoRequerido = 0;
        enganche = 0;
        avaluo = 0;
        comisionApertura = 0;
        gastosNotariales = 0;
        desembolsoTotal = 0;

        // Scotiabank
        scotiabank = Simula.getForCalc(3, $scope.selMens, $scope.selPlazo);
        var grpScotiabank = [];
        grpScotiabank.push({
            name: scotiabank.nombreBanco,
            members: []
        });

        aforo = scotiabank.aforo;
        factorPago = scotiabank.factorDePago;
        tasaInteres = scotiabank.tasaDeInteres;
        cat = scotiabank.cat;

        montoCredito = Calculos.calculaMotoDelCredito(scotiabank.aforo, $scope.valor);
        pagoMensual = Calculos.calcularPagoMensual(montoCredito, factorPago);
        ingresoRequerido = Calculos.calculoIngresoRequeridoCreciente(pagoMensual, 3);

        enganche = Calculos.calculoEnganche($scope.valor, montoCredito);
        avaluo = Calculos.calcularAvaluoCreciente($scope.valor, 3, Avaluos);
        comisionApertura = Calculos.calculoComisionApertura(montoCredito, 3);
        gastosNotariales = Calculos.calculoGastosNotariales($scope.valor, gastosNotarialesXEstado);

        desembolsoTotal = parseFloat(enganche) + parseFloat(avaluo) + parseFloat(comisionApertura) + parseFloat(gastosNotariales);

        grpScotiabank[0].members.push({ name: "Pago mensual", quantity: '$' + pagoMensual.formatMoney(2, '.', ',') });
        grpScotiabank[0].members.push({ name: "Monto del credito", quantity: '$' + montoCredito.formatMoney(2, '.', ',') });
        grpScotiabank[0].members.push({ name: "Tasa de interes", quantity: (tasaInteres * 100).toFixed(2) + '%' });
        grpScotiabank[0].members.push({ name: "Ingreso requerido", quantity: '$' + ingresoRequerido.formatMoney(2, '.', ',') });
        grpScotiabank[0].members.push({ name: "Incremento anual del pago", quantity: parseFloat(banorte.incrementoAnual * 100).toFixed(2) + "%" });
        grpScotiabank[0].members.push({ name: "CAT", quantity: (cat * 100).toFixed(2) + '%' });
        grpScotiabank[0].members.push({ name: "Gastos del credito", quantity: undefined });
        grpScotiabank[0].members.push({ name: "Enganche", quantity: '$' + enganche.formatMoney(2, '.', ',') });
        grpScotiabank[0].members.push({ name: "Avaluo", quantity: '$' + avaluo.formatMoney(2, '.', ',') });
        grpScotiabank[0].members.push({ name: "Comision por apertura", quantity: '$' + comisionApertura.formatMoney(2, '.', ',') });
        grpScotiabank[0].members.push({ name: "Gastos notariales", quantity: '$' + gastosNotariales.formatMoney(2, '.', ',') });
        grpScotiabank[0].members.push({ name: "Desembolso total", quantity: '$' + desembolsoTotal.formatMoney(2, '.', ',') });

        $scope.grupoScotiabank = grpScotiabank;

        aforo = 0;
        factorPago = 0;
        tasaInteres = 0;
        cat = 0;
        montoCredito = 0;
        pagoMensual = 0;
        ingresoRequerido = 0;
        enganche = 0;
        avaluo = 0;
        comisionApertura = 0;
        gastosNotariales = 0;
        desembolsoTotal = 0;

        // Afirme
        afirme = Simula.getForCalc(5, $scope.selMens, $scope.selPlazo);
        var grpAfirme = [];
        grpAfirme.push({
            name: afirme.nombreBanco,
            members: []
        });

        aforo = afirme.aforo;
        factorPago = afirme.factorDePago;
        tasaInteres = afirme.tasaDeInteres;
        cat = afirme.cat;

        montoCredito = Calculos.calculaMotoDelCredito(afirme.aforo, $scope.valor);
        pagoMensual = Calculos.calcularPagoMensual(montoCredito, factorPago);
        ingresoRequerido = Calculos.calculoIngresoRequeridoCreciente(pagoMensual, 3);

        enganche = Calculos.calculoEnganche($scope.valor, montoCredito);
        avaluo = Calculos.calcularAvaluoCreciente($scope.valor, 3, Avaluos);
        comisionApertura = Calculos.calculoComisionApertura(montoCredito, 3);
        gastosNotariales = Calculos.calculoGastosNotariales($scope.valor, gastosNotarialesXEstado);

        desembolsoTotal = parseFloat(enganche) + parseFloat(avaluo) + parseFloat(comisionApertura) + parseFloat(gastosNotariales);

        grpAfirme[0].members.push({ name: "Pago mensual", quantity: '$' + pagoMensual.formatMoney(2, '.', ',') });
        grpAfirme[0].members.push({ name: "Monto del credito", quantity: '$' + montoCredito.formatMoney(2, '.', ',') });
        grpAfirme[0].members.push({ name: "Tasa de interes", quantity: (tasaInteres * 100).toFixed(2) + '%' });
        grpAfirme[0].members.push({ name: "Ingreso requerido", quantity: '$' + ingresoRequerido.formatMoney(2, '.', ',') });
        grpAfirme[0].members.push({ name: "Incremento anual del pago", quantity: parseFloat(banorte.incrementoAnual * 100).toFixed(2) + "%" });
        grpAfirme[0].members.push({ name: "CAT", quantity: (cat * 100).toFixed(2) + '%' });
        grpAfirme[0].members.push({ name: "Gastos del credito", quantity: undefined });
        grpAfirme[0].members.push({ name: "Enganche", quantity: '$' + enganche.formatMoney(2, '.', ',') });
        grpAfirme[0].members.push({ name: "Avaluo", quantity: '$' + avaluo.formatMoney(2, '.', ',') });
        grpAfirme[0].members.push({ name: "Comision por apertura", quantity: '$' + comisionApertura.formatMoney(2, '.', ',') });
        grpAfirme[0].members.push({ name: "Gastos notariales", quantity: '$' + gastosNotariales.formatMoney(2, '.', ',') });
        grpAfirme[0].members.push({ name: "Desembolso total", quantity: '$' + desembolsoTotal.formatMoney(2, '.', ',') });

        $scope.grupoAfirme = grpAfirme;

        aforo = 0;
        factorPago = 0;
        tasaInteres = 0;
        cat = 0;
        montoCredito = 0;
        pagoMensual = 0;
        ingresoRequerido = 0;
        enganche = 0;
        avaluo = 0;
        comisionApertura = 0;
        gastosNotariales = 0;
        desembolsoTotal = 0;

        // HSBC
        hsbc = Simula.getForCalc(7, $scope.selMens, $scope.selPlazo);
        var grpHSBC = [];
        grpHSBC.push({
            name: hsbc.nombreBanco,
            members: []
        });

        aforo = hsbc.aforo;
        factorPago = hsbc.factorDePago;
        tasaInteres = hsbc.tasaDeInteres;
        cat = hsbc.cat;

        montoCredito = Calculos.calculaMotoDelCredito(hsbc.aforo, $scope.valor);
        pagoMensual = Calculos.calcularPagoMensual(montoCredito, factorPago);
        ingresoRequerido = Calculos.calculoIngresoRequeridoCreciente(pagoMensual, 3);

        enganche = Calculos.calculoEnganche($scope.valor, montoCredito);
        avaluo = Calculos.calcularAvaluoCreciente($scope.valor, 3, Avaluos);
        comisionApertura = Calculos.calculoComisionApertura(montoCredito, 3);
        gastosNotariales = Calculos.calculoGastosNotariales($scope.valor, gastosNotarialesXEstado);

        desembolsoTotal = parseFloat(enganche) + parseFloat(avaluo) + parseFloat(comisionApertura) + parseFloat(gastosNotariales);

        grpHSBC[0].members.push({ name: "Pago mensual", quantity: '$' + pagoMensual.formatMoney(2, '.', ',') });
        grpHSBC[0].members.push({ name: "Monto del credito", quantity: '$' + montoCredito.formatMoney(2, '.', ',') });
        grpHSBC[0].members.push({ name: "Tasa de interes", quantity: (tasaInteres * 100).toFixed(2) + '%' });
        grpHSBC[0].members.push({ name: "Ingreso requerido", quantity: '$' + ingresoRequerido.formatMoney(2, '.', ',') });
        grpHSBC[0].members.push({ name: "Incremento anual del pago", quantity: parseFloat(banorte.incrementoAnual * 100).toFixed(2) + "%" });
        grpHSBC[0].members.push({ name: "CAT", quantity: (cat * 100).toFixed(2) + '%' });
        grpHSBC[0].members.push({ name: "Gastos del credito", quantity: undefined });
        grpHSBC[0].members.push({ name: "Enganche", quantity: '$' + enganche.formatMoney(2, '.', ',') });
        grpHSBC[0].members.push({ name: "Avaluo", quantity: '$' + avaluo.formatMoney(2, '.', ',') });
        grpHSBC[0].members.push({ name: "Comision por apertura", quantity: '$' + comisionApertura.formatMoney(2, '.', ',') });
        grpHSBC[0].members.push({ name: "Gastos notariales", quantity: '$' + gastosNotariales.formatMoney(2, '.', ',') });
        grpHSBC[0].members.push({ name: "Desembolso total", quantity: '$' + desembolsoTotal.formatMoney(2, '.', ',') });
        $scope.grupoHSBC = grpHSBC;

        aforo = 0;
        factorPago = 0;
        tasaInteres = 0;
        cat = 0;
        montoCredito = 0;
        pagoMensual = 0;
        ingresoRequerido = 0;
        enganche = 0;
        avaluo = 0;
        comisionApertura = 0;
        gastosNotariales = 0;
        desembolsoTotal = 0;
    });
})();